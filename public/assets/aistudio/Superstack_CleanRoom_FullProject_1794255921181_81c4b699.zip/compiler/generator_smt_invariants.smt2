; SMT-LIB2 Verification Suite for Sovereign Compiler v∞
(set-logic QF_BV)
; Invariant 1: Hard EOF Sentinel Present
(declare-const eof_sentinel_present Bool)
; Invariant 2: Hash Match on Replay Reassembly
(declare-const hash_match_replay Bool)
; Invariant 3: Max Affine File Size Bounded <= 512KB
(declare-const file_size (_ BitVec 32))
(assert eof_sentinel_present)
(assert hash_match_replay)
(assert (bvule file_size #x00080000))
(check-sat)
; SAT - Soundness Proved Under Zero-Truncation Compiler Invariant Matrix
