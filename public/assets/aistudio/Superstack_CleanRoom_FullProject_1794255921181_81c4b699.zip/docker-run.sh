#!/usr/bin/env bash
echo "=== Building and launching Sovereign Infinity Node ==="
docker build -t superstack-council-clean-app:latest .
docker run -p 3000:3000 --name superstack-council-clean-app-instance superstack-council-clean-app:latest
