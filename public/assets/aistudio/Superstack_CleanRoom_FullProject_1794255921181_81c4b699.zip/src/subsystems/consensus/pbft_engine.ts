// ============================================================================
// SOVEREIGN BYZANTINE FAULT TOLERANT (PBFT) CONSENSUS ENGINE
// Formal Byzantine Quorum: N = 5 nodes, f = 1 Byzantine failure tolerance.
// Quorum threshold: 2f + 1 = 4 affirmative votes required for state transition.
// ============================================================================

export type PBFTPhase = 'NEW_ROUND' | 'PRE_PREPARE' | 'PREPARE' | 'COMMIT' | 'COMMITTED' | 'VIEW_CHANGE';

export interface ProposalVote {
  readonly nodeId: string;
  readonly city: string;
  readonly viewNumber: number;
  readonly sequenceNumber: number;
  readonly digest: string;
  readonly signature: string;
  readonly timestamp: number;
}

export interface PBFTStateBlock {
  readonly sequenceNumber: number;
  readonly viewNumber: number;
  readonly proposerId: string;
  readonly stateDigest: string;
  readonly payload: unknown;
  readonly prepareVotes: ProposalVote[];
  readonly commitVotes: ProposalVote[];
  readonly finalizedAt: number;
}

export class SovereignPBFTConsensusNode {
  public viewNumber = 0;
  public sequenceNumber = 0;
  public phase: PBFTPhase = 'NEW_ROUND';
  private preparedBlocks = new Map<number, PBFTStateBlock>();
  private committedBlocks: PBFTStateBlock[] = [];
  private currentPrepareVotes = new Map<string, ProposalVote>();
  private currentCommitVotes = new Map<string, ProposalVote>();

  constructor(
    public readonly nodeId: string,
    public readonly city: string,
    public readonly totalNodes = 5,
    public readonly maxFaulty = 1
  ) {}

  public get quorumThreshold(): number {
    return 2 * this.maxFaulty + 1; // 3 for N=4, 4 for N=5
  }

  public prePrepare(digest: string, payload: unknown): { broadcastMessage: string; sequenceNumber: number } {
    this.sequenceNumber++;
    this.phase = 'PRE_PREPARE';
    this.currentPrepareVotes.clear();
    this.currentCommitVotes.clear();

    // Proposer casts initial prepare vote
    this.castVote('PREPARE', digest);

    return {
      broadcastMessage: `PRE_PREPARE:seq=${this.sequenceNumber}:view=${this.viewNumber}:digest=${digest}`,
      sequenceNumber: this.sequenceNumber
    };
  }

  public handlePrepareVote(vote: ProposalVote): boolean {
    if (vote.viewNumber !== this.viewNumber || vote.sequenceNumber !== this.sequenceNumber) {
      return false;
    }

    this.currentPrepareVotes.set(vote.nodeId, vote);

    // Check if 2f+1 prepare quorum reached
    if (this.currentPrepareVotes.size >= this.quorumThreshold && this.phase === 'PRE_PREPARE') {
      this.phase = 'PREPARE';
      this.castVote('COMMIT', vote.digest);
      return true;
    }
    return false;
  }

  public handleCommitVote(vote: ProposalVote): boolean {
    if (vote.viewNumber !== this.viewNumber || vote.sequenceNumber !== this.sequenceNumber) {
      return false;
    }

    this.currentCommitVotes.set(vote.nodeId, vote);

    // Check if 2f+1 commit quorum reached
    if (this.currentCommitVotes.size >= this.quorumThreshold && this.phase === 'PREPARE') {
      this.phase = 'COMMITTED';
      const finalizedBlock: PBFTStateBlock = {
        sequenceNumber: this.sequenceNumber,
        viewNumber: this.viewNumber,
        proposerId: this.nodeId,
        stateDigest: vote.digest,
        payload: { committedRound: this.sequenceNumber },
        prepareVotes: Array.from(this.currentPrepareVotes.values()),
        commitVotes: Array.from(this.currentCommitVotes.values()),
        finalizedAt: Date.now()
      };
      this.committedBlocks.push(finalizedBlock);
      this.phase = 'NEW_ROUND';
      return true;
    }
    return false;
  }

  private castVote(phase: 'PREPARE' | 'COMMIT', digest: string): void {
    const vote: ProposalVote = {
      nodeId: this.nodeId,
      city: this.city,
      viewNumber: this.viewNumber,
      sequenceNumber: this.sequenceNumber,
      digest,
      signature: `SIG_${this.nodeId}_${phase}_${this.sequenceNumber}_${Date.now()}`,
      timestamp: Date.now()
    };
    if (phase === 'PREPARE') this.currentPrepareVotes.set(this.nodeId, vote);
    if (phase === 'COMMIT') this.currentCommitVotes.set(this.nodeId, vote);
  }

  public triggerViewChange(): number {
    this.viewNumber++;
    this.phase = 'VIEW_CHANGE';
    this.currentPrepareVotes.clear();
    this.currentCommitVotes.clear();
    return this.viewNumber;
  }

  public getCommittedLedger(): readonly PBFTStateBlock[] {
    return this.committedBlocks;
  }
}
