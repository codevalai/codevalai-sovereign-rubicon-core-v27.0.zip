// ============================================================================
// SOVEREIGN DETERMINISTIC DISCRETE-EVENT SCHEDULER & REPLAY ENGINE
// Virtual-time execution model guarantees zero-drift cross-machine reproducibility.
// ============================================================================

export interface ScheduledTask {
  readonly taskId: string;
  readonly virtualTimeNs: bigint;
  readonly priority: number;
  readonly handlerName: string;
  readonly payload: unknown;
}

export class Mulberry32PRNG {
  private state: number;

  constructor(seed: number) {
    this.state = seed >>> 0;
  }

  public next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
}

export class DeterministicVirtualScheduler {
  private currentVirtualTimeNs = 0n;
  private taskQueue: ScheduledTask[] = [];
  public readonly prng: Mulberry32PRNG;

  constructor(seed = 133742) {
    this.prng = new Mulberry32PRNG(seed);
  }

  public schedule(delayNs: bigint, priority: number, handlerName: string, payload: unknown): string {
    const taskId = 'task-' + this.taskQueue.length + '-' + Math.floor(this.prng.next() * 10000);
    const virtualTimeNs = this.currentVirtualTimeNs + delayNs;

    const task: ScheduledTask = {
      taskId,
      virtualTimeNs,
      priority,
      handlerName,
      payload
    };

    this.taskQueue.push(task);
    // Sort strictly by virtual timestamp, then by priority, then by taskId
    this.taskQueue.sort((a, b) => {
      if (a.virtualTimeNs !== b.virtualTimeNs) {
        return a.virtualTimeNs < b.virtualTimeNs ? -1 : 1;
      }
      if (a.priority !== b.priority) {
        return b.priority - a.priority;
      }
      return a.taskId.localeCompare(b.taskId);
    });

    return taskId;
  }

  public step(): ScheduledTask | null {
    if (this.taskQueue.length === 0) return null;
    const task = this.taskQueue.shift()!;
    this.currentVirtualTimeNs = task.virtualTimeNs;
    return task;
  }

  public getVirtualTimeNs(): bigint {
    return this.currentVirtualTimeNs;
  }

  public pendingTasksCount(): number {
    return this.taskQueue.length;
  }
}
