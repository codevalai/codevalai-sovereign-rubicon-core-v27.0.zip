// ============================================================================
// SOVEREIGN GAS METERING & ECONOMICS ENGINE
// Computes computational fees, prevents infinite loops, and enforces balance conservation.
// ============================================================================

export interface GasSchedule {
  readonly baseTransactionGas: number;
  readonly storagePerByteGas: number;
  readonly cryptoVerifyGas: number;
  readonly quicPacketGas: number;
  readonly aiInferencePerTokenGas: number;
}

export const DEFAULT_GAS_SCHEDULE: GasSchedule = {
  baseTransactionGas: 21000,
  storagePerByteGas: 16,
  cryptoVerifyGas: 3000,
  quicPacketGas: 100,
  aiInferencePerTokenGas: 50
};

export class GasMeter {
  public gasConsumed = 0;

  constructor(public readonly gasLimit: number, public readonly schedule: GasSchedule = DEFAULT_GAS_SCHEDULE) {}

  public consume(amount: number, operation: string): void {
    if (this.gasConsumed + amount > this.gasLimit) {
      throw new Error(`[OUT_OF_GAS] Operation '${operation}' required ${amount} gas, exceeding limit ${this.gasLimit} (consumed: ${this.gasConsumed})`);
    }
    this.gasConsumed += amount;
  }

  public chargeStorage(bytes: number): void {
    this.consume(bytes * this.schedule.storagePerByteGas, 'STORAGE_WRITE');
  }

  public chargeCryptoVerification(): void {
    this.consume(this.schedule.cryptoVerifyGas, 'PQC_SIGNATURE_VERIFY');
  }

  public chargeAIInference(tokens: number): void {
    this.consume(tokens * this.schedule.aiInferencePerTokenGas, 'AI_INFERENCE_STEP');
  }
}

export interface AccountLedger {
  readonly did: string;
  balance: bigint;
  nonce: bigint;
}

export class DoubleEntryTreasury {
  private accounts = new Map<string, AccountLedger>();

  public getBalance(did: string): bigint {
    return this.accounts.get(did)?.balance ?? 0n;
  }

  public deposit(did: string, amount: bigint): void {
    const acc = this.accounts.get(did) || { did, balance: 0n, nonce: 0n };
    acc.balance += amount;
    this.accounts.set(did, acc);
  }

  public transfer(fromDid: string, toDid: string, amount: bigint, fee: bigint, nonce: bigint): void {
    const sender = this.accounts.get(fromDid);
    if (!sender) throw new Error(`Sender ${fromDid} not found`);
    if (sender.nonce !== nonce) throw new Error(`Invalid nonce: expected ${sender.nonce}, got ${nonce}`);
    if (sender.balance < amount + fee) throw new Error(`Insufficient funds for transfer and gas`);

    const recipient = this.accounts.get(toDid) || { did: toDid, balance: 0n, nonce: 0n };
    sender.balance -= (amount + fee);
    sender.nonce += 1n;
    recipient.balance += amount;

    this.accounts.set(fromDid, sender);
    this.accounts.set(toDid, recipient);
  }
}
