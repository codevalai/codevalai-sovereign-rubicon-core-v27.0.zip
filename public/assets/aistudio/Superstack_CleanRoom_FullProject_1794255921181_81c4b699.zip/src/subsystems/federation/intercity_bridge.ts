// ============================================================================
// SOVEREIGN INTER-CITY FEDERATION & TREATY BRIDGE
// Manages cross-city Merkle root anchors, dispute quarantine, and treaty compliance.
// ============================================================================

export interface FederationAnchor {
  readonly originCity: 'Tokyo' | 'Zurich' | 'Reykjavik' | 'Singapore' | 'Virginia';
  readonly epoch: number;
  readonly merkleRoot: string;
  readonly blockHeight: number;
  readonly validatorSignatures: string[];
  readonly anchoredAt: number;
}

export interface CityTreatyStatus {
  readonly city: string;
  inCompliance: boolean;
  activeQuarantine: boolean;
  disputeCount: number;
  lastAnchorEpoch: number;
}

export class SovereignFederationBridge {
  private anchors = new Map<string, FederationAnchor[]>();
  private treaties = new Map<string, CityTreatyStatus>();

  constructor() {
    this.initTreaties();
  }

  private initTreaties(): void {
    const cities = ['Tokyo', 'Zurich', 'Reykjavik', 'Singapore', 'Virginia'];
    for (const c of cities) {
      this.treaties.set(c, {
        city: c,
        inCompliance: true,
        activeQuarantine: false,
        disputeCount: 0,
        lastAnchorEpoch: 0
      });
      this.anchors.set(c, []);
    }
  }

  public registerCrossCityAnchor(anchor: FederationAnchor): { accepted: boolean; quarantineTriggered: boolean } {
    const status = this.treaties.get(anchor.originCity);
    if (!status || status.activeQuarantine) {
      return { accepted: false, quarantineTriggered: true };
    }

    // Require at least 3 validator signatures for cross-city anchoring
    if (anchor.validatorSignatures.length < 3) {
      status.activeQuarantine = true;
      status.disputeCount++;
      return { accepted: false, quarantineTriggered: true };
    }

    status.lastAnchorEpoch = anchor.epoch;
    this.anchors.get(anchor.originCity)!.push(anchor);
    return { accepted: true, quarantineTriggered: false };
  }

  public getTreatyMatrix(): CityTreatyStatus[] {
    return Array.from(this.treaties.values());
  }
}
