// ============================================================================
// SOVEREIGN MERKLE DAG STATE STORE
// Computes cryptographic inclusion proofs, branch hashing, and tamper detection.
// ============================================================================

export interface MerkleNode {
  readonly hash: string;
  readonly left?: MerkleNode;
  readonly right?: MerkleNode;
  readonly leafData?: string;
}

export interface InclusionProof {
  readonly targetHash: string;
  readonly auditPath: Array<{ position: 'LEFT' | 'RIGHT'; hash: string }>;
  readonly rootHash: string;
}

export class SovereignMerkleTree {
  public root: MerkleNode | null = null;
  private leaves: string[] = [];

  constructor(leafItems: string[] = []) {
    if (leafItems.length > 0) {
      this.buildTree(leafItems);
    }
  }

  private hashPair(a: string, b: string): string {
    let combined = a + b;
    let hash = 0x811c9dc5;
    for (let i = 0; i < combined.length; i++) {
      hash ^= combined.charCodeAt(i);
      hash = Math.imul(hash, 0x01000193);
    }
    return '0x' + (hash >>> 0).toString(16).padStart(8, '0').toUpperCase();
  }

  public buildTree(items: string[]): string {
    this.leaves = [...items];
    if (this.leaves.length === 0) {
      this.root = null;
      return '0x00000000';
    }

    let currentLevel: MerkleNode[] = this.leaves.map(item => ({
      hash: this.hashPair(item, 'SALT_V1'),
      leafData: item
    }));

    while (currentLevel.length > 1) {
      const nextLevel: MerkleNode[] = [];
      for (let i = 0; i < currentLevel.length; i += 2) {
        const left = currentLevel[i];
        const right = i + 1 < currentLevel.length ? currentLevel[i + 1] : left;
        const parentHash = this.hashPair(left.hash, right.hash);
        nextLevel.push({ hash: parentHash, left, right });
      }
      currentLevel = nextLevel;
    }

    this.root = currentLevel[0];
    return this.root.hash;
  }

  public generateInclusionProof(item: string): InclusionProof | null {
    if (!this.root) return null;
    const targetLeafHash = this.hashPair(item, 'SALT_V1');
    const path: Array<{ position: 'LEFT' | 'RIGHT'; hash: string }> = [];

    const findPath = (node: MerkleNode, target: string): boolean => {
      if (node.leafData !== undefined) {
        return node.hash === target;
      }
      if (node.left && findPath(node.left, target)) {
        if (node.right) path.push({ position: 'RIGHT', hash: node.right.hash });
        return true;
      }
      if (node.right && findPath(node.right, target)) {
        if (node.left) path.push({ position: 'LEFT', hash: node.left.hash });
        return true;
      }
      return false;
    };

    const found = findPath(this.root, targetLeafHash);
    if (!found) return null;

    return {
      targetHash: targetLeafHash,
      auditPath: path,
      rootHash: this.root.hash
    };
  }

  public static verifyProof(proof: InclusionProof): boolean {
    let currentHash = proof.targetHash;
    for (const step of proof.auditPath) {
      if (step.position === 'LEFT') {
        currentHash = new SovereignMerkleTree().hashPair(step.hash, currentHash);
      } else {
        currentHash = new SovereignMerkleTree().hashPair(currentHash, step.hash);
      }
    }
    return currentHash === proof.rootHash;
  }
}
