-- ============================================================================
-- SOVEREIGN RELATIONAL LEDGER & AUDIT SCHEMA (PostgreSQL / SQLite WAL Engine)
-- ============================================================================

CREATE TABLE IF NOT EXISTS sovereign_blocks (
    block_height BIGINT PRIMARY KEY,
    block_hash VARCHAR(64) NOT NULL UNIQUE,
    parent_hash VARCHAR(64) NOT NULL,
    merkle_root VARCHAR(64) NOT NULL,
    proposer_city VARCHAR(32) NOT NULL,
    consensus_round INT NOT NULL,
    quorum_signatures JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS state_transitions (
    tx_hash VARCHAR(64) PRIMARY KEY,
    block_height BIGINT REFERENCES sovereign_blocks(block_height),
    sender_did VARCHAR(128) NOT NULL,
    recipient_did VARCHAR(128) NOT NULL,
    op_code VARCHAR(32) NOT NULL,
    gas_consumed BIGINT NOT NULL,
    state_diff JSONB NOT NULL,
    ml_kem_signature VARCHAR(256) NOT NULL,
    executed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS agent_capabilities (
    did VARCHAR(128) PRIMARY KEY,
    role_name VARCHAR(64) NOT NULL,
    assigned_city VARCHAR(32) NOT NULL,
    gas_allowance BIGINT NOT NULL DEFAULT 1000000000,
    permission_mask BIGINT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    last_nonce BIGINT NOT NULL DEFAULT 0,
    public_key_pem TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_transitions_block ON state_transitions(block_height);
CREATE INDEX IF NOT EXISTS idx_transitions_sender ON state_transitions(sender_did);
