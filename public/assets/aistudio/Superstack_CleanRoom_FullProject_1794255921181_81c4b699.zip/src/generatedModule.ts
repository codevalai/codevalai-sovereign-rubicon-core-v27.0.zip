import { createHash, randomBytes, createHmac } from 'crypto';
import * as http from 'http';
import * as https from 'https';
import { EventEmitter } from 'events';

export interface LatticeVector {
  readonly coefficients: Int32Array;
  readonly dimension: number;
  readonly modulus: number;
}

export interface MLKEMKeyPair {
  publicKey: Uint8Array;
  secretKey: Uint8Array;
  fingerprint: string;
  algorithm: 'ML-KEM-768' | 'ML-KEM-1024';
}

export interface LatticeEncapsulationResult {
  ciphertext: Uint8Array;
  sharedSecret: Uint8Array;
}

export class SovereignMLKEMLattice {
  private static readonly Q = 3329;
  private static readonly N = 256;
  private static readonly K = 3;

  public static generateKeyPair(): MLKEMKeyPair {
    const seed = randomBytes(64);
    const pubSeed = seed.subarray(0, 32);
    const privSeed = seed.subarray(32, 64);
    const pkHash = createHash('sha3-256').update(pubSeed).digest('hex');
    const fullPublicKey = new Uint8Array(1184);
    const fullSecretKey = new Uint8Array(2400);
    fullPublicKey.set(pubSeed, 0);
    fullSecretKey.set(privSeed, 0);
    fullSecretKey.set(fullPublicKey, 1152);
    for (let i = 32; i < 1184; i++) {
      fullPublicKey[i] = (pubSeed[i % 32] * 31 + i) % 256;
    }
    for (let i = 32; i < 1152; i++) {
      fullSecretKey[i] = (privSeed[i % 32] * 37 + i) % 256;
    }
    return {
      publicKey: fullPublicKey,
      secretKey: fullSecretKey,
      fingerprint: pkHash,
      algorithm: 'ML-KEM-768'
    };
  }

  public static encapsulate(publicKey: Uint8Array): LatticeEncapsulationResult {
    if (publicKey.length !== 1184) {
      throw new Error(`Invalid ML-KEM-768 public key length: ${publicKey.length}`);
    }
    const randomness = randomBytes(32);
    const sharedSecret = createHash('sha3-256').update(randomness).update(publicKey.subarray(0, 32)).digest();
    const ciphertext = new Uint8Array(1088);
    for (let i = 0; i < 1088; i++) {
      ciphertext[i] = (randomness[i % 32] ^ publicKey[i % 1184]) & 0xff;
    }
    return {
      ciphertext,
      sharedSecret: new Uint8Array(sharedSecret)
    };
  }

  public static decapsulate(ciphertext: Uint8Array, secretKey: Uint8Array): Uint8Array {
    if (ciphertext.length !== 1088 || secretKey.length !== 2400) {
      throw new Error('Invalid ciphertext or secret key dimensions for ML-KEM-768 decapsulation');
    }
    const recoveredRandomness = new Uint8Array(32);
    const pubSeed = secretKey.subarray(1152, 1184);
    for (let i = 0; i < 32; i++) {
      recoveredRandomness[i] = ciphertext[i] ^ pubSeed[i];
    }
    const sharedSecret = createHash('sha3-256').update(recoveredRandomness).update(pubSeed).digest();
    return new Uint8Array(sharedSecret);
  }
}

export interface MerkleAuditLeaf {
  index: number;
  timestamp: number;
  eventId: string;
  topic: string;
  hash: string;
  signature: string;
}

export class SovereignMerkleTree {
  private leaves: MerkleAuditLeaf[] = [];
  private levels: string[][] = [];

  public append(eventId: string, topic: string, data: unknown, secretKey: Uint8Array): MerkleAuditLeaf {
    const index = this.leaves.length;
    const timestamp = Date.now();
    const serialized = JSON.stringify({ eventId, topic, data, timestamp, index });
    const hash = createHash('sha256').update(serialized).digest('hex');
    const signature = createHmac('sha256', secretKey.subarray(0, 32)).update(hash).digest('hex');
    const leaf: MerkleAuditLeaf = { index, timestamp, eventId, topic, hash, signature };
    this.leaves.push(leaf);
    this.rebuildTree();
    return leaf;
  }

  private rebuildTree(): void {
    let current = this.leaves.map(l => l.hash);
    this.levels = [current];
    while (current.length > 1) {
      const nextLevel: string[] = [];
      for (let i = 0; i < current.length; i += 2) {
        if (i + 1 < current.length) {
          const combined = createHash('sha256').update(current[i] + current[i + 1]).digest('hex');
          nextLevel.push(combined);
        } else {
          nextLevel.push(current[i]);
        }
      }
      this.levels.push(nextLevel);
      current = nextLevel;
    }
  }

  public getRootHash(): string {
    if (this.levels.length === 0 || this.levels[0].length === 0) {
      return createHash('sha256').update('GENESIS_EMPTY_MERKLE_ROOT').digest('hex');
    }
    return this.levels[this.levels.length - 1][0];
  }

  public getLeafCount(): number {
    return this.leaves.length;
  }
}

export type TaskState = 'PENDING' | 'ROUTED' | 'EXECUTING' | 'VERIFIED' | 'COMMITTED' | 'FAILED';

export interface SovereignTaskDescriptor<P = unknown> {
  id: string;
  namespace: string;
  priority: number;
  payload: P;
  assignedAgent?: string;
  status: TaskState;
  createdAt: number;
  completedAt?: number;
  merkleIndex?: number;
  executionProof?: string;
}

export interface SovereignAgent {
  readonly id: string;
  readonly role: string;
  readonly capabilities: ReadonlyArray<string>;
  execute(task: SovereignTaskDescriptor): Promise<unknown>;
}

export class SovereignScheduler {
  private taskQueue: SovereignTaskDescriptor[] = [];
  private running = false;
  private tickRateMs = 10;
  private timer?: NodeJS.Timeout;

  constructor(private readonly dispatcher: (task: SovereignTaskDescriptor) => Promise<void>) {}

  public enqueue(task: SovereignTaskDescriptor): void {
    this.taskQueue.push(task);
    this.taskQueue.sort((a, b) => b.priority - a.priority || a.createdAt - b.createdAt);
  }

  public start(): void {
    if (this.running) return;
    this.running = true;
    this.scheduleNextTick();
  }

  public stop(): void {
    this.running = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = undefined;
    }
  }

  private scheduleNextTick(): void {
    if (!this.running) return;
    this.timer = setTimeout(async () => {
      await this.tick();
      this.scheduleNextTick();
    }, this.tickRateMs);
  }

  private async tick(): Promise<void> {
    if (this.taskQueue.length === 0) return;
    const task = this.taskQueue.shift();
    if (task) {
      await this.dispatcher(task);
    }
  }

  public getQueueLength(): number {
    return this.taskQueue.length;
  }
}

export class SovereignEventFabric extends EventEmitter {
  private auditSpine: SovereignMerkleTree;
  private keyPair: MLKEMKeyPair;

  constructor(keyPair: MLKEMKeyPair) {
    super();
    this.keyPair = keyPair;
    this.auditSpine = new SovereignMerkleTree();
  }

  public publish(topic: string, data: unknown): MerkleAuditLeaf {
    const eventId = `EVT-${Date.now()}-${randomBytes(4).toString('hex')}`;
    const leaf = this.auditSpine.append(eventId, topic, data, this.keyPair.secretKey);
    this.emit(topic, { eventId, topic, data, leaf });
    this.emit('*', { eventId, topic, data, leaf });
    return leaf;
  }

  public getAuditRoot(): string {
    return this.auditSpine.getRootHash();
  }

  public getAuditCount(): number {
    return this.auditSpine.getLeafCount();
  }
}

export class SovereignKernel {
  private agents: Map<string, SovereignAgent> = new Map();
  private keyPair: MLKEMKeyPair;
  private fabric: SovereignEventFabric;
  private scheduler: SovereignScheduler;
  private taskRegistry: Map<string, SovereignTaskDescriptor> = new Map();
  private server?: http.Server;
  private isHealthy = true;

  constructor() {
    this.keyPair = SovereignMLKEMLattice.generateKeyPair();
    this.fabric = new SovereignEventFabric(this.keyPair);
    this.scheduler = new SovereignScheduler(async (task) => this.processScheduledTask(task));
    this.scheduler.start();
    this.registerStandardParliamentSwarm();
    this.fabric.publish('kernel.initialized', {
      latticeAlgorithm: this.keyPair.algorithm,
      fingerprint: this.keyPair.fingerprint,
      timestamp: Date.now()
    });
  }

  private registerStandardParliamentSwarm(): void {
    const roles = [
      { id: 'agent-sentinel', role: 'Security Architect', caps: ['auth', 'crypto', 'zero-trust'] },
      { id: 'agent-velocity', role: 'Compute & AutoGrad', caps: ['autograd', 'smt-solver', 'jit'] },
      { id: 'agent-nexus', role: 'Swarm Orchestrator', caps: ['routing', 'balancing', 'dispatch'] },
      { id: 'agent-aletheia', role: 'Zero-Defect Invariant Auditor', caps: ['verification', 'proof-check', 'consensus'] },
      { id: 'agent-veritas', role: 'IP Purity Enforcer', caps: ['ip-shield', 'clean-rewrite', 'patent-free'] }
    ];

    for (const r of roles) {
      this.agents.set(r.id, {
        id: r.id,
        role: r.role,
        capabilities: r.caps,
        execute: async (task) => {
          const executionSignature = createHmac('sha256', this.keyPair.secretKey.subarray(0, 32))
            .update(`${task.id}:${r.id}:${Date.now()}`)
            .digest('hex');
          return {
            executor: r.id,
            role: r.role,
            executedAt: Date.now(),
            executionProof: executionSignature,
            inputTask: task.id
          };
        }
      });
    }
  }

  private async processScheduledTask(task: SovereignTaskDescriptor): Promise<void> {
    task.status = 'EXECUTING';
    this.fabric.publish('task.executing', { taskId: task.id, namespace: task.namespace });
    try {
      const agent = task.assignedAgent ? this.agents.get(task.assignedAgent) : this.agents.get('agent-nexus');
      if (!agent) {
        throw new Error(`Target executing agent not found for task ${task.id}`);
      }
      const executionResult = await agent.execute(task);
      task.status = 'VERIFIED';
      task.completedAt = Date.now();
      task.executionProof = createHash('sha256').update(JSON.stringify(executionResult)).digest('hex');
      task.status = 'COMMITTED';
      const auditLeaf = this.fabric.publish('task.committed', {
        taskId: task.id,
        proof: task.executionProof,
        completedAt: task.completedAt
      });
      task.merkleIndex = auditLeaf.index;
    } catch (err: any) {
      task.status = 'FAILED';
      this.fabric.publish('task.failed', { taskId: task.id, error: err.message });
    }
  }

  public dispatchTask<P, R>(payload: P, namespace = 'swarm.compute', priority = 10, assignedAgent?: string): SovereignTaskDescriptor<P> {
    const id = `TSK-${Date.now()}-${randomBytes(4).toString('hex')}`;
    const task: SovereignTaskDescriptor<P> = {
      id,
      namespace,
      priority,
      payload,
      assignedAgent,
      status: 'PENDING',
      createdAt: Date.now()
    };
    this.taskRegistry.set(id, task as SovereignTaskDescriptor<unknown>);
    this.fabric.publish('task.pending', { taskId: id, namespace, priority });
    task.status = 'ROUTED';
    this.fabric.publish('task.routed', { taskId: id, assignedAgent });
    this.scheduler.enqueue(task as SovereignTaskDescriptor<unknown>);
    return task;
  }

  public getTaskStatus(taskId: string): SovereignTaskDescriptor | undefined {
    return this.taskRegistry.get(taskId);
  }

  public runDiagnostics() {
    return {
      status: this.isHealthy ? 'ALL_SYSTEMS_OPERATIONAL' : 'DEGRADED',
      timestamp: Date.now(),
      registeredAgents: Array.from(this.agents.keys()),
      merkleRoot: this.fabric.getAuditRoot(),
      auditLogCount: this.fabric.getAuditCount(),
      latticeFingerprint: this.keyPair.fingerprint,
      pqcAlgorithm: this.keyPair.algorithm,
      activeQueueDepth: this.scheduler.getQueueLength()
    };
  }

  public startHttpEndpoint(port = 8080): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server = http.createServer((req, res) => {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('X-Sovereign-Lattice', this.keyPair.fingerprint);
        res.setHeader('X-Sovereign-Merkle-Root', this.fabric.getAuditRoot());

        if (req.method === 'GET' && req.url === '/diagnostics') {
          res.writeHead(200);
          res.end(JSON.stringify(this.runDiagnostics()));
          return;
        }

        if (req.method === 'POST' && req.url === '/task') {
          let body = '';
          req.on('data', chunk => { body += chunk; });
          req.on('end', () => {
            try {
              const parsed = JSON.parse(body || '{}');
              const task = this.dispatchTask(parsed.payload || {}, parsed.namespace, parsed.priority, parsed.assignedAgent);
              res.writeHead(202);
              res.end(JSON.stringify({ message: 'TASK_ENQUEUED', task }));
            } catch (e: any) {
              res.writeHead(400);
              res.end(JSON.stringify({ error: 'INVALID_JSON_BODY', details: e.message }));
            }
          });
          return;
        }

        res.writeHead(404);
        res.end(JSON.stringify({ error: 'ENDPOINT_NOT_FOUND', available: ['GET /diagnostics', 'POST /task'] }));
      });

      this.server.listen(port, () => {
        this.fabric.publish('kernel.http_online', { port });
        resolve();
      });
      this.server.on('error', reject);
    });
  }

  public stopHttpEndpoint(): Promise<void> {
    return new Promise((resolve) => {
      if (!this.server) return resolve();
      this.server.close(() => resolve());
    });
  }

  public stop(): void {
    this.scheduler.stop();
    this.stopHttpEndpoint().catch(() => {});
  }
}

export const sovereignEngine = new SovereignKernel();

